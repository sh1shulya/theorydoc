<?php
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/db.php';

// Читаем JSON-тело
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Неверный формат данных.'], JSON_UNESCAPED_UNICODE);
    exit;
}

function field($arr, $key) {
    return isset($arr[$key]) ? trim((string)$arr[$key]) : '';
}

$panelType     = field($data, 'panelType');
$specification = field($data, 'specification');
$customerName  = field($data, 'customerName');
$address       = field($data, 'address');
$phone         = field($data, 'phone');

if ($panelType === '' || $specification === '' || $customerName === '' || $address === '' || $phone === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Все поля формы обязательны для заполнения.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt = $mysqli->prepare("
    INSERT INTO orders (panel_type, specification, customer_name, address, phone)
    VALUES (?, ?, ?, ?, ?)
");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка подготовки запроса.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt->bind_param('sssss', $panelType, $specification, $customerName, $address, $phone);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Заказ успешно сохранен.'], JSON_UNESCAPED_UNICODE);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка при сохранении заказа.'], JSON_UNESCAPED_UNICODE);
}

$stmt->close();

