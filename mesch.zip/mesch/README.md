# Сайт ЭлектроЩит

## Источники
- Изображения взяты с сайтов: 
  https://ru.freepik.com/
  https://www.rkm-electro.ru/
  https://chint.ru/
- Тексты сгенерированы при помощи:
  https://sinonim.org/gen