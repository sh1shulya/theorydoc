window.addEventListener('load', function() {
    if (!document.body || document.body.innerHTML.trim() === '') {
        window.location.href = '404.html';
    }
});
