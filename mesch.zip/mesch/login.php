<?php
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/db.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Неверный формат данных.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$username = isset($data['username']) ? trim((string)$data['username']) : '';
$password = isset($data['password']) ? trim((string)$data['password']) : '';

if ($username === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Введите логин и пароль.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt = $mysqli->prepare("SELECT id, username, password_hash FROM admins WHERE username = ?");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка запроса.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt->bind_param('s', $username);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

if (!$admin || !password_verify($password, $admin['password_hash'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Неверный логин или пароль.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$_SESSION['admin_id'] = (int)$admin['id'];
$_SESSION['admin_username'] = $admin['username'];

echo json_encode(['success' => true, 'message' => 'Успешная авторизация.'], JSON_UNESCAPED_UNICODE);

