const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;

// --- Инициализация базы данных ---
const dbPath = path.join(__dirname, 'data.sqlite');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(
    `CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      panel_type TEXT NOT NULL,
      specification TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      address TEXT NOT NULL,
      phone TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`
  );

  db.run(
    `CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL
    )`
  );

  // Создаем дефолтного администратора, если его нет
  const defaultUsername = 'admin';
  const defaultPassword = 'admin123';

  db.get('SELECT id FROM admins WHERE username = ?', [defaultUsername], async (err, row) => {
    if (err) {
      console.error('Ошибка при проверке администратора:', err);
      return;
    }
    if (!row) {
      try {
        const hash = await bcrypt.hash(defaultPassword, 10);
        db.run(
          'INSERT INTO admins (username, password_hash) VALUES (?, ?)',
          [defaultUsername, hash],
          (insertErr) => {
            if (insertErr) {
              console.error('Ошибка создания администратора по умолчанию:', insertErr);
            } else {
              console.log('Создан администратор по умолчанию: login=admin, password=admin123');
            }
          }
        );
      } catch (hashErr) {
        console.error('Ошибка хеширования пароля администратора:', hashErr);
      }
    }
  });
});

// --- Настройка middleware ---
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(
  session({
    secret: 'change-this-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      maxAge: 1000 * 60 * 60 // 1 час
    }
  })
);

// Раздача статики (формы и скрипты)
app.use(express.static(path.join(__dirname, 'public')));

// --- Middleware для проверки авторизации администратора ---
function requireAdmin(req, res, next) {
  if (!req.session || !req.session.adminId) {
    return res.status(401).json({ success: false, message: 'Требуется авторизация администратора' });
  }
  next();
}

// --- Маршруты API ---

// Добавление заказа
app.post('/api/orders', (req, res) => {
  const { panelType, specification, customerName, address, phone } = req.body;

  if (
    !panelType ||
    !specification ||
    !customerName ||
    !address ||
    !phone ||
    !String(panelType).trim() ||
    !String(specification).trim() ||
    !String(customerName).trim() ||
    !String(address).trim() ||
    !String(phone).trim()
  ) {
    return res.status(400).json({ success: false, message: 'Все поля формы обязательны для заполнения.' });
  }

  const stmt = db.prepare(
    `INSERT INTO orders (panel_type, specification, customer_name, address, phone)
     VALUES (?, ?, ?, ?, ?)`
  );
  stmt.run(panelType, specification, customerName, address, phone, function (err) {
    if (err) {
      console.error('Ошибка при сохранении заказа:', err);
      return res.status(500).json({ success: false, message: 'Ошибка сервера при сохранении заказа.' });
    }
    res.json({ success: true, message: 'Заказ успешно сохранен.', orderId: this.lastID });
  });
  stmt.finalize();
});

// Авторизация администратора
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Введите логин и пароль.' });
  }

  db.get('SELECT * FROM admins WHERE username = ?', [username], async (err, admin) => {
    if (err) {
      console.error('Ошибка при поиске администратора:', err);
      return res.status(500).json({ success: false, message: 'Ошибка сервера.' });
    }

    if (!admin) {
      return res.status(401).json({ success: false, message: 'Неверный логин или пароль.' });
    }

    const match = await bcrypt.compare(password, admin.password_hash);
    if (!match) {
      return res.status(401).json({ success: false, message: 'Неверный логин или пароль.' });
    }

    req.session.adminId = admin.id;
    res.json({ success: true, message: 'Успешная авторизация.' });
  });
});

// Выход администратора
app.post('/api/logout', (req, res) => {
  if (req.session) {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  } else {
    res.json({ success: true });
  }
});

// Получение списка заказов (только для авторизованного администратора)
app.get('/api/orders', requireAdmin, (req, res) => {
  db.all(
    'SELECT id, panel_type, specification, customer_name, address, phone, created_at FROM orders ORDER BY created_at DESC',
    [],
    (err, rows) => {
      if (err) {
        console.error('Ошибка при получении заказов:', err);
        return res.status(500).json({ success: false, message: 'Ошибка сервера при получении заказов.' });
      }
      res.json({ success: true, orders: rows });
    }
  );
});

// Защищенный HTML для просмотра заказов: отдаем одну страницу, которая уже сама дергает /api/orders
app.get('/admin/orders', (req, res) => {
  if (!req.session || !req.session.adminId) {
    return res.redirect('/admin.html');
  }
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Главная страница с формой заказа
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'order.html'));
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});

