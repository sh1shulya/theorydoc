<?php
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/db.php';

if (empty($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Требуется авторизация.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$orders = [];

$result = $mysqli->query("
    SELECT id, panel_type, specification, customer_name, address, phone, created_at
    FROM orders
    ORDER BY created_at DESC
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Ошибка получения заказов.'], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['success' => true, 'orders' => $orders], JSON_UNESCAPED_UNICODE);

