<?php
// Настройки подключения к MySQL — ЗАПОЛНИТЕ ПОД СВОЙ ХОСТИНГ
$db_host = 'localhost';
$db_name = 'ВАША_БАЗА';
$db_user = 'ВАШ_ПОЛЬЗОВАТЕЛЬ';
$db_pass = 'ВАШ_ПАРОЛЬ';

$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($mysqli->connect_errno) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'message' => 'Ошибка подключения к базе данных: ' . $mysqli->connect_error,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$mysqli->set_charset('utf8mb4');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Создание таблиц при первом обращении
$mysqli->query("
    CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        panel_type VARCHAR(255) NOT NULL,
        specification TEXT NOT NULL,
        customer_name VARCHAR(255) NOT NULL,
        address VARCHAR(500) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$mysqli->query("
    CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Создаем администратора по умолчанию, если таблица пуста
$res = $mysqli->query("SELECT COUNT(*) AS cnt FROM admins");
if ($res) {
    $row = $res->fetch_assoc();
    if ((int)$row['cnt'] === 0) {
        $defaultUsername = 'admin';
        $defaultPassword = 'admin123';
        $hash = password_hash($defaultPassword, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param('ss', $defaultUsername, $hash);
            $stmt->execute();
            $stmt->close();
        }
    }
}

