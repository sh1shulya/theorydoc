-- SQL-скрипт для создания базы данных и таблиц

-- 1. Создать базу данных (при необходимости измените имя)
CREATE DATABASE IF NOT EXISTS mesch_panel_orders
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE mesch_panel_orders;

-- 2. Таблица заказов электрощитов
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    panel_type VARCHAR(255) NOT NULL,
    specification TEXT NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    address VARCHAR(500) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Таблица администраторов
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Администратор по умолчанию: логин admin, пароль admin123
INSERT INTO admins (username, password_hash)
VALUES (
  'admin',
  '$2y$10$YUF9RQm9ycGs4XL.WY0AcO7G0XyCkH7uP9Ty4cqG6Z2G4vVOHHcAW'
)
ON DUPLICATE KEY UPDATE username = username;

